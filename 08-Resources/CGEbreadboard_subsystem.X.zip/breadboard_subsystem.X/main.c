#include "mcc_generated_files/system/system.h"
#include <xc.h>
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

// ---------- ADC / mapping ----------
#define ADC_MAX_COUNTS   4095.0f   // PIC18F57Q43 12-bit
#define VREF_V           5.0f      // change to 3.3f if your board uses 3.3V
#define VMIN_V           0.10f
#define VMAX_V           4.90f

// ---------- Demo thresholds & timing (tweakable) ----------
#define RH_IMMEDIATE_THRESHOLD    85.0f   // immediate (demo sensitive)
#define RH_SUSTAINED_THRESHOLD    70.0f   // sustained
#define SUSTAINED_MS              3000    // sustained duration (3 s) - demo short
#define DELTA_RH_THRESHOLD        10.0f   // percent jump considered leak (demo sensitive)
#define DELTA_WINDOW_MS           5000    // 5 seconds window for delta detection
#define TEMP_IMMEDIATE_THRESHOLD_C   60.0f
#define TEMP_HYSTERESIS_C            5.0f

// Clearing
#define HYSTERESIS_RH             5.0f
#define CLEAR_DEBOUNCE_MS         2000    // 2s before clearing

// Loop timing
#define LOOP_DELAY_MS             50      // sample every 50 ms (20 Hz)

// Derived for history
#define DELTA_SAMPLES             (DELTA_WINDOW_MS / LOOP_DELAY_MS)
#define RH_HISTORY_SIZE           (DELTA_SAMPLES + 4) // a little extra

// ---------- Globals ----------
static float rh_history[RH_HISTORY_SIZE];
static uint16_t rh_history_idx = 0;
static uint32_t loop_counter = 0;
static uint32_t sustained_counter_ms = 0;
static uint32_t clear_debounce_counter_ms = 0;
static bool alarm_on = false;

// ---------- Helpers ----------
static float adc_to_voltage(uint16_t counts) {
    return ((float)counts * VREF_V) / ADC_MAX_COUNTS;
}
static float voltage_to_norm(float v) {
    float n = (v - VMIN_V) / (VMAX_V - VMIN_V);
    if (n < 0.0f) n = 0.0f;
    if (n > 1.0f) n = 1.0f;
    return n;
}
static void record_rh(float rh) {
    rh_history[rh_history_idx++] = rh;
    if (rh_history_idx >= RH_HISTORY_SIZE) rh_history_idx = 0;
}
static float rh_from_samples_ago(uint16_t samples_ago) {
    if (samples_ago >= RH_HISTORY_SIZE) return 0.0f;
    int32_t idx = (int32_t)rh_history_idx - (int32_t)samples_ago;
    while (idx < 0) idx += RH_HISTORY_SIZE;
    return rh_history[idx];
}
static void alarm_activate(void) {
    if (!alarm_on) {
        alarm_on = true;
        IO_RF4_SetHigh();   // alarm LED on
        IO_RD5_SetLow();    // alert active low
    }
}
static void alarm_clear(void) {
    if (alarm_on) {
        alarm_on = false;
        IO_RF4_SetLow();
        IO_RD5_SetHigh();
    }
}

// ---------- Main ----------
int main(void)
{
    SYSTEM_Initialize();

    // safe startup
    IO_RD5_SetHigh();
    IO_RF4_SetLow();

    // init history
    for (uint16_t i=0;i<RH_HISTORY_SIZE;i++) rh_history[i]=0.0f;

    while (1) {
        // --- read ADCs ---
        ADC_ChannelSelect(ADC_CHANNEL_ANA0); // RA0 = Temp
        ADC_ConversionStart();
        while (!ADC_IsConversionDone());
        uint16_t adc_temp = (uint16_t)ADC_ConversionResultGet();

        ADC_ChannelSelect(ADC_CHANNEL_ANA1); // RA1 = RH
        ADC_ConversionStart();
        while (!ADC_IsConversionDone());
        uint16_t adc_rh = (uint16_t)ADC_ConversionResultGet();

        // --- convert ---
        float v_temp = adc_to_voltage(adc_temp);
        float v_rh   = adc_to_voltage(adc_rh);
        float norm_temp = voltage_to_norm(v_temp);
        float norm_rh   = voltage_to_norm(v_rh);
        float tempC = -40.0f + 165.0f * norm_temp; // SHT-like mapping
        float rh    = 100.0f * norm_rh;

        // --- record recent RH for delta detection ---
        record_rh(rh);
        loop_counter++;

        // --- Immediate alarms ---
        if (tempC >= TEMP_IMMEDIATE_THRESHOLD_C) {
            alarm_activate();
            sustained_counter_ms = 0;
            clear_debounce_counter_ms = 0;
        } else if (rh >= RH_IMMEDIATE_THRESHOLD) {
            alarm_activate();
            sustained_counter_ms = 0;
            clear_debounce_counter_ms = 0;
        } else {
            // --- sustained RH check (short demo window) ---
            if (rh >= RH_SUSTAINED_THRESHOLD) {
                sustained_counter_ms += LOOP_DELAY_MS;
                if (sustained_counter_ms >= SUSTAINED_MS) {
                    alarm_activate();
                    sustained_counter_ms = 0;
                    clear_debounce_counter_ms = 0;
                }
            } else {
                sustained_counter_ms = 0;
            }

            // --- delta detection: compare current RH to RH DELTA_WINDOW_MS ago ---
            uint16_t samples_ago = (uint16_t)DELTA_SAMPLES;
            float old_rh = rh_from_samples_ago(samples_ago);
            if (old_rh > 0.0f && (rh - old_rh) >= DELTA_RH_THRESHOLD) {
                alarm_activate();
                sustained_counter_ms = 0;
                clear_debounce_counter_ms = 0;
            }
        }

        // --- clearing logic: require both RH and Temp to be safely low for CLEAR_DEBOUNCE_MS ---
        bool temp_clear_ok = (tempC <= (TEMP_IMMEDIATE_THRESHOLD_C - TEMP_HYSTERESIS_C));
        if (alarm_on) {
            if ((rh <= (RH_SUSTAINED_THRESHOLD - HYSTERESIS_RH)) && temp_clear_ok) {
                clear_debounce_counter_ms += LOOP_DELAY_MS;
                if (clear_debounce_counter_ms >= CLEAR_DEBOUNCE_MS) {
                    alarm_clear();
                    clear_debounce_counter_ms = 0;
                    sustained_counter_ms = 0;
                }
            } else {
                clear_debounce_counter_ms = 0;
            }
        }

        // --- debug output for tuning ---
        printf("RH:%3.1f%% T:%3.1fC\r\n", rh, tempC);

        __delay_ms(LOOP_DELAY_MS);
    }
    return 0;
} 
